/*
 * This package intentionally contains no executable third-party script.
 * The first-party TemplatePackageRenderer enables the reviewed wedding-envelope
 * behavior for this template: envelope opening, countdown, reveal transitions,
 * and falling petals. RSVP is handled by the platform's public RSVP component.
 */
